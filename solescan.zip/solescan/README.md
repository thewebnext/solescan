# SoleScan — AI Foot & Shoe Analyzer

Upload a foot photo → AI analyzes shape, arch, width → get your exact size across 9 brands + 6 shoe recommendations.

---

## 🚀 Deploy in 5 Minutes (Free)

### Option A — Railway (Recommended, Easiest)

1. **Create a free account** at [railway.app](https://railway.app)
2. **Click "New Project" → "Deploy from GitHub repo"**
   - Push this folder to a GitHub repo first (or use Railway's CLI)
3. **Set your environment variable:**
   - Go to your project → Variables tab
   - Add: `ANTHROPIC_API_KEY` = your key from [console.anthropic.com](https://console.anthropic.com)
4. **Deploy!** Railway gives you a public URL like `https://solescan.up.railway.app`

Anyone with that link can use the app instantly.

---

### Option B — Render (Also Free)

1. Push this folder to a GitHub repo
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your GitHub repo
4. Build command: `npm install`
5. Start command: `node server.js`
6. Add env variable: `ANTHROPIC_API_KEY` = your key
7. Click Deploy → get your public URL

---

### Option C — Run Locally

```bash
# Install dependencies
npm install

# Set your API key
export ANTHROPIC_API_KEY=sk-ant-your-key-here

# Start the server
npm start

# Open in browser
open http://localhost:3000
```

---

## 📁 File Structure

```
solescan/
├── server.js          # Express backend (proxies Anthropic API securely)
├── package.json       # Dependencies
├── render.yaml        # Render deployment config
├── railway.toml       # Railway deployment config
└── public/
    └── index.html     # The full web app UI
```

## 🔑 Why a Backend Server?

The backend proxy keeps your Anthropic API key secret. Without it, anyone could open DevTools and steal your key. The server receives requests from the browser and forwards them to Anthropic with the key — users never see it.

## 💡 Features

- 📸 Drag-and-drop or click-to-upload foot photo
- 🦶 AI analyzes: arch type, toe shape, width classification
- 📏 Returns US, EU, UK sizes + estimated measurements
- 👟 Size conversion for 9 brands: Nike, Adidas, New Balance, Converse, Vans, Skechers, ASICS, Puma, Reebok
- 💬 Expert podiatric advice personalized to your foot
- 🛒 6 mid-range shoe recommendations matched to your budget and use case
